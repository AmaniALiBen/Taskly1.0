// js/index.js

// ============================================
// DATA (Will be replaced by API calls)
// ============================================
const categoriesData = [
    { id: 1, name: "Design", icon: "fa-palette", color: "#a78bfa", bg: "rgba(124, 58, 237, 0.15)" },
    { id: 2, name: "Coding", icon: "fa-code", color: "#60a5fa", bg: "rgba(59, 130, 246, 0.15)" },
    { id: 3, name: "Video", icon: "fa-video", color: "#f87171", bg: "rgba(239, 68, 68, 0.15)" },
    { id: 4, name: "Writing", icon: "fa-pen", color: "#4ade80", bg: "rgba(34, 197, 94, 0.15)" },
    { id: 5, name: "Ads", icon: "fa-bullhorn", color: "#facc15", bg: "rgba(234, 179, 8, 0.15)" },
    { id: 6, name: "Music", icon: "fa-music", color: "#f472b6", bg: "rgba(236, 72, 153, 0.15)" }
];

const gigsList = [
    { id: 1, title: "Modern Luxury Brand Identity Design", price: 80, category: "Design", freelancer: "Ahmed B.", avatar: "https://i.pravatar.cc/100?u=1", image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800", rating: 4.9 },
    { id: 2, title: "Full Stack Web Application Development", price: 350, category: "Coding", freelancer: "Sara M.", avatar: "https://i.pravatar.cc/100?u=2", image: "https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=800", rating: 5.0 },
    { id: 3, title: "Social Media Video Marketing Content", price: 120, category: "Video", freelancer: "Omar K.", avatar: "https://i.pravatar.cc/100?u=3", image: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800", rating: 4.8 },
    { id: 4, title: "Business Strategy & Growth Consulting", price: 150, category: "Ads", freelancer: "Layla T.", avatar: "https://i.pravatar.cc/100?u=4", image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800", rating: 4.7 },
    { id: 5, title: "UI/UX Design for Mobile App", price: 200, category: "Design", freelancer: "Nadia R.", avatar: "https://i.pravatar.cc/100?u=5", image: "https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?w=800", rating: 4.9 },
    { id: 6, title: "Backend API Development", price: 400, category: "Coding", freelancer: "Khaled M.", avatar: "https://i.pravatar.cc/100?u=6", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800", rating: 4.8 }
];

// ============================================
// AUTHENTICATION STATE GLOBAL VARIABLES
// ============================================
let isLoggedIn = false;
let currentUser = null;
let categorySwiper = null;

function getBasePath() {
    return window.location.pathname.includes('/pages/') ? '../' : '';
}

// ============================================
// FETCH USER AVATAR FROM DATABASE
// ============================================
async function fetchUserAvatar() {
    try {
        const response = await fetch('/Taskly/controllers/getUser.php', {
            cache: 'no-cache'
        });
        const data = await response.json();

        if (data.loggedIn) {
            const avatarImg = document.getElementById('user-avatar-img');
            if (!avatarImg) return;

            if (data.avatar && data.avatar !== '' && data.avatar !== 'null') {
                avatarImg.src = data.avatar + '?t=' + Date.now();
            } else if (data.username) {
                avatarImg.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(data.username)}&background=7c3aed&color=fff&size=100`;
            }
        }
    } catch (error) {
        console.error('Avatar error:', error);
    }
}

// ============================================
// FETCH USER DATA FROM SERVER ON LOAD
// ============================================
async function fetchUserData() {
    try {
        const response = await fetch('/Taskly/controllers/getUser.php');
        const data = await response.json();

        if (data.loggedIn) {
            isLoggedIn = true;
            currentUser = {
                name: data.username,
                email: data.email,
                role: data.role,
                avatar: data.avatar
            };
            updateUIForLoggedInUser();
        } else {
            isLoggedIn = false;
            currentUser = null;
            updateUIForLoggedOutUser();
        }
    } catch (error) {
        console.error('Error fetching user:', error);
        updateUIForLoggedOutUser();
    }
}

async function checkAuthStatus() {
    await fetchUserData();
}

// ============================================
// UPDATE UI INTERFACES FOR AUTH STATE
// ============================================
function updateUIForLoggedInUser() {
    const authButtons = document.getElementById('auth-buttons');
    const userMenu = document.getElementById('user-menu');
    const adminLink = document.getElementById('admin-link');

    // أولاً: أظهر القائمة وأخفِ أزرار Auth
    if (authButtons) authButtons.classList.add('hidden');
    if (userMenu) userMenu.classList.remove('hidden');

    // ثانياً: حدّث الصورة بعد ما العنصر صار ظاهر في DOM
    fetchUserAvatar();

    if (adminLink) {
        adminLink.style.display = (currentUser && currentUser.role === 'admin') ? 'inline-block' : 'none';
    }
}

function updateUIForLoggedOutUser() {
    const authButtons = document.getElementById('auth-buttons');
    const userMenu = document.getElementById('user-menu');
    const adminLink = document.getElementById('admin-link');
    const userAvatarImg = document.getElementById('user-avatar-img');

    if (authButtons) authButtons.classList.remove('hidden');
    if (userMenu) userMenu.classList.add('hidden');
    if (adminLink) adminLink.style.display = 'none';
    if (userAvatarImg) userAvatarImg.src = 'https://i.pravatar.cc/100?u=default';

    hideDropdown();
}

// ============================================
// TOAST NOTIFICATIONS
// ============================================
function showToast(message, type = 'success') {
    let toast = document.getElementById('custom-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'custom-toast';
        toast.className = 'toast-notification';
        document.body.appendChild(toast);
    }
    if (window.toastTimeout) clearTimeout(window.toastTimeout);

    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.innerHTML = `<i class="fas ${icon}" style="margin-right: 8px;"></i> ${message}`;
    toast.className = `toast-notification ${type}`;
    toast.classList.add('show');

    window.toastTimeout = setTimeout(() => toast.classList.remove('show'), 3000);
}

// ============================================
// NAVIGATION
// ============================================
function goToOrders() {
    if (!isLoggedIn) {
        showToast('Please login to view your orders', 'error');
        openLoginModal();
        return;
    }
    window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? 'orders.html' : 'pages/orders.html');
}

function goToProfile() {
    if (!isLoggedIn) {
        showToast('Please login to view your profile', 'error');
        openLoginModal();
        return;
    }
    window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? 'profile.html' : 'pages/profile.html');
}

// ============================================
// CATEGORY SLIDER
// ============================================
function initCategorySlider() {
    const container = document.getElementById('categories-container');
    if (!container) return;

    container.innerHTML = categoriesData.map(cat => `
        <div class="swiper-slide">
            <div class="category-item" data-category="${cat.name}" onclick="filterByCategory('${cat.name}')">
                <div class="category-icon" style="background: ${cat.bg}; color: ${cat.color};">
                    <i class="fas ${cat.icon}"></i>
                </div>
                <span class="category-label">${cat.name}</span>
            </div>
        </div>
    `).join('');

    if (categorySwiper) categorySwiper.destroy(true, true);

    categorySwiper = new Swiper('.category-slider', {
        slidesPerView: 2,
        spaceBetween: 15,
        freeMode: true,
        mousewheel: true,
        navigation: {
            nextEl: '.swiper-button-next-custom',
            prevEl: '.swiper-button-prev-custom',
        },
        breakpoints: {
            480: { slidesPerView: 3, spaceBetween: 15 },
            640: { slidesPerView: 4, spaceBetween: 15 },
            768: { slidesPerView: 5, spaceBetween: 20 },
            1024: { slidesPerView: 6, spaceBetween: 20 },
        }
    });
}

function filterByCategory(categoryName) {
    if (!isLoggedIn) {
        showToast('Please login to view gigs', 'error');
        openLoginModal();
        return;
    }
    window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? `gigs.html?category=${encodeURIComponent(categoryName)}` : `pages/gigs.html?category=${encodeURIComponent(categoryName)}`);
}

// ============================================
// SEARCH
// ============================================
function handleSearch() {
    const searchInput = document.getElementById('search-input');
    const searchTerm = searchInput ? searchInput.value.trim() : '';

    if (!searchTerm) {
        showToast('Please enter a search term', 'error');
        return;
    }

    if (!isLoggedIn) {
        showToast('Please login to search for gigs', 'error');
        openLoginModal();
        return;
    }

    window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? `gigs.html?search=${encodeURIComponent(searchTerm)}` : `pages/gigs.html?search=${encodeURIComponent(searchTerm)}`);
}

function setupSearchEnterKey() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleSearch();
            }
        });
    }
}

// ============================================
// RENDER GIGS
// ============================================
function renderAvailableGigs() {
    const container = document.getElementById('gigs-main-container');
    if (!container) return;

    container.innerHTML = gigsList.map(gig => `
        <div class="gig-card" onclick="navigateToGigDetails(${gig.id})">
            <div class="gig-image-container">
                <img src="${gig.image}" alt="${gig.title}" loading="lazy">
            </div>
            <div class="gig-body-content">
                <div class="gig-seller-info">
                    <img src="${gig.avatar}" class="seller-avatar">
                    <span class="seller-name">${gig.freelancer}</span>
                </div>
                <span class="gig-category-badge">${gig.category}</span>
                <h3 class="gig-title-text">${gig.title}</h3>
                <div class="gig-footer-info">
                    <div class="rating-display">
                        <i class="fas fa-star"></i> ${gig.rating}
                    </div>
                    <div>
                        <span class="price-label">Starting at</span>
                        <span class="price-value">$${gig.price}</span>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function navigateToGigDetails(gigId) {
    if (!isLoggedIn) {
        showToast('Please login to view gig details', 'error');
        openLoginModal();
        return;
    }
    window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? `gig-details.html?id=${gigId}` : `pages/gig-details.html?id=${gigId}`);
}

// ============================================
// MODALS
// ============================================
function openRoleModal() {
    const modal = document.getElementById('roleModal');
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
}

function closeRoleModal() {
    const modal = document.getElementById('roleModal');
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = 'auto'; }
}

function selectBuyer() {
    closeRoleModal();
    openBuyerModal();
}

function selectSeller() {
    closeRoleModal();
    setTimeout(() => {
        window.location.href = getBasePath() + (window.location.pathname.includes('/pages/') ? 'CreateSellerAccount.html' : 'pages/CreateSellerAccount.html');
    }, 500);
}

function openBuyerModal() {
    const modal = document.getElementById('buyerModal');
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
}

function closeBuyerModal() {
    const modal = document.getElementById('buyerModal');
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = 'auto'; }
    const form = document.getElementById('buyerSignupForm');
    if (form) form.reset();
}

function openLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
}

function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = 'auto'; }
    const form = document.getElementById('loginForm');
    if (form) form.reset();
}

function openTermsModal() {
    const modal = document.getElementById('termsModal');
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
}

function closeTermsModal() {
    const modal = document.getElementById('termsModal');
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = 'auto'; }
}

function acceptTerms() {
    const termsCheckbox = document.getElementById('buyerTerms');
    if (termsCheckbox) termsCheckbox.checked = true;
    closeTermsModal();
    showToast('You have accepted the Terms and Conditions', 'success');
}

// ============================================
// BUYER AVATAR PREVIEW
// ============================================
function setupBuyerAvatarPreview() {
    const buyerProfilePic = document.getElementById('buyerProfilePic');
    const buyerAvatarPreview = document.getElementById('buyerAvatarPreview');

    if (buyerProfilePic && buyerAvatarPreview) {
        buyerProfilePic.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (event) {
                    buyerAvatarPreview.style.backgroundImage = `url(${event.target.result})`;
                    buyerAvatarPreview.style.backgroundSize = 'cover';
                    buyerAvatarPreview.style.backgroundPosition = 'center';
                    buyerAvatarPreview.innerHTML = '';
                };
                reader.readAsDataURL(file);
            } else {
                buyerAvatarPreview.innerHTML = '<i class="fas fa-camera" style="font-size: 24px; color: var(--primary-color);"></i>';
                buyerAvatarPreview.style.backgroundImage = 'none';
            }
        });
    }
}

// ============================================
// DROPDOWN MENU
// ============================================
function hideDropdown() {
    const dropdown = document.getElementById('user-dropdown');
    if (dropdown) {
        dropdown.classList.remove('show-dropdown');
        dropdown.classList.add('hide-dropdown');
    }
}

function toggleUserMenu(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('user-dropdown');
    if (dropdown) {
        if (dropdown.classList.contains('hide-dropdown')) {
            dropdown.classList.remove('hide-dropdown');
            dropdown.classList.add('show-dropdown');
        } else {
            dropdown.classList.remove('show-dropdown');
            dropdown.classList.add('hide-dropdown');
        }
    }
}

document.addEventListener('click', function (e) {
    const dropdown = document.getElementById('user-dropdown');
    const avatar = document.querySelector('.user-avatar');
    if (dropdown && avatar) {
        if (!avatar.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.remove('show-dropdown');
            dropdown.classList.add('hide-dropdown');
        }
    }
});

// ============================================
// LOGOUT MODAL
// ============================================
function openLogoutModal() {
    const modal = document.getElementById('logoutModal');
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
}

function closeLogoutModal() {
    const modal = document.getElementById('logoutModal');
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = 'auto'; }
}

async function confirmLogout() {
    closeLogoutModal();

    try {
        await fetch('/Taskly/controllers/logout.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
    } catch (error) {
        console.error('Logout error:', error);
    }

    localStorage.clear();
    document.cookie.split(";").forEach(function (c) {
        document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
    });

    isLoggedIn = false;
    currentUser = null;

    const authButtons = document.getElementById('auth-buttons');
    const userMenu = document.getElementById('user-menu');
    if (authButtons) authButtons.classList.remove('hidden');
    if (userMenu) userMenu.classList.add('hidden');

    hideDropdown();
    showToast("Logged out successfully", "success");

    setTimeout(() => window.location.reload(), 1000);
}

function handleLogout() {
    openLogoutModal();
}

// ============================================
// LOGIN HANDLER
// ============================================
async function handleLogin(e) {
    if (e) e.preventDefault();

    const emailEl = document.getElementById('loginEmail');
    const passwordEl = document.getElementById('loginPassword');
    const rememberEl = document.getElementById('rememberMe');

    if (!emailEl || !passwordEl) return;

    const email = emailEl.value.trim();
    const password = passwordEl.value;
    const remember = rememberEl ? rememberEl.checked : false;

    if (!email || !password) return showToast('Please fill in all fields', 'error');

    try {
        const response = await fetch('/Taskly/controllers/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, remember })
        });
        const data = await response.json();

        if (data.success) {
            isLoggedIn = true;
            currentUser = {
                name: data.username,
                email: data.email,
                role: data.role,
                id: data.user_id
            };

            localStorage.setItem('userRole', data.role);
            localStorage.setItem('userId', data.user_id);
            localStorage.setItem('userName', data.username);

            if (remember) {
                localStorage.setItem('rememberedEmail', email);
            } else {
                localStorage.removeItem('rememberedEmail');
            }

            showToast(`Welcome back, ${data.username}!`, 'success');
            closeLoginModal();
            updateUIForLoggedInUser();

            setTimeout(() => {
                if (data.role === 'seller') {
                    window.location.href = '/Taskly/pages/sellerDashboard.html';
                } else if (data.role === 'admin') {
                    window.location.href = '/Taskly/pages/admin.html';
                } else {
                    window.location.reload();
                }
            }, 1000);
        } else {
            showToast(data.message || 'Invalid email or password', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('Login failed', 'error');
    }
}

// ============================================
// BUYER SIGNUP HANDLER
// ============================================
async function handleBuyerSignup(e) {
    if (e) e.preventDefault();

    const nameEl = document.getElementById('buyerName');
    const emailEl = document.getElementById('buyerEmail');
    const passwordEl = document.getElementById('buyerPassword');
    const confirmEl = document.getElementById('buyerConfirmPassword');
    const termsEl = document.getElementById('buyerTerms');
    const profilePicEl = document.getElementById('buyerProfilePic');

    if (!nameEl || !emailEl || !passwordEl || !confirmEl) {
        showToast('Form error, please refresh the page', 'error');
        return;
    }

    const name = nameEl.value.trim();
    const email = emailEl.value.trim();
    const password = passwordEl.value;
    const confirm = confirmEl.value;
    const terms = termsEl ? termsEl.checked : false;
    const profilePic = profilePicEl ? profilePicEl.files[0] : null;

    if (!name || !email || !password || !confirm) return showToast('Please fill in all fields', 'error');
    if (!email.includes('@') || !email.includes('.')) return showToast('Valid email required', 'error');
    if (password.length < 8) return showToast('Password must be 8+ characters', 'error');
    if (password !== confirm) return showToast('Passwords do not match', 'error');
    if (!terms) return showToast('You must accept the Terms & Conditions', 'error');

    const submitBtn = document.querySelector('#buyerSignupForm button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : 'Register';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
    }

    try {
        const formData = new FormData();
        formData.append('username', name);
        formData.append('email', email);
        formData.append('password', password);
        if (profilePic) formData.append('profilePic', profilePic);

        const response = await fetch('/Taskly/controllers/registerBuyer.php', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (data.success) {
            showToast('Account created successfully! Please login.', 'success');

            nameEl.value = '';
            emailEl.value = '';
            passwordEl.value = '';
            confirmEl.value = '';
            if (termsEl) termsEl.checked = false;
            if (profilePicEl) profilePicEl.value = '';

            const preview = document.getElementById('buyerAvatarPreview');
            if (preview) {
                preview.innerHTML = '<i class="fas fa-camera" style="font-size: 24px; color: var(--primary-color);"></i>';
                preview.style.backgroundImage = 'none';
            }

            closeBuyerModal();
            setTimeout(() => openLoginModal(), 1000);
        } else {
            showToast(data.message || 'Signup failed. Please try again.', 'error');
        }
    } catch (error) {
        console.error('Fetch error:', error);
        showToast('Server error: ' + error.message, 'error');
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    }
}

// ============================================
// GLOBAL MODAL CLOSE HANDLERS
// ============================================
window.onclick = function (e) {
    if (e.target.classList.contains('modal-overlay')) {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
        document.body.style.overflow = 'auto';
    }
    if (e.target.classList.contains('terms-modal-overlay')) closeTermsModal();
    if (e.target.classList.contains('logout-modal-overlay')) closeLogoutModal();
};

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay, .terms-modal-overlay, .logout-modal-overlay').forEach(m => m.classList.remove('active'));
        document.body.style.overflow = 'auto';
    }
});

// ============================================
// INITIALIZATION
// ============================================
window.onload = function () {
    hideDropdown();
    renderAvailableGigs();
    initCategorySlider();
    checkAuthStatus();
    setupSearchEnterKey();
    setupBuyerAvatarPreview();

    if (localStorage.getItem('triggerPopup') === 'true') {
        openLoginModal();
        localStorage.removeItem('triggerPopup');
    }

    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail) {
        const emailInput = document.getElementById('loginEmail');
        if (emailInput) emailInput.value = rememberedEmail;
        const rememberCheckbox = document.getElementById('rememberMe');
        if (rememberCheckbox) rememberCheckbox.checked = true;
    }

    const buyerForm = document.getElementById('buyerSignupForm');
    if (buyerForm) {
        buyerForm.removeAttribute('onsubmit');
        buyerForm.addEventListener('submit', handleBuyerSignup);
    }

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
};
